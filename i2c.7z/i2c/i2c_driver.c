/*
 * Copyright 2018~2019 JLQ Technology Co., Ltd. or its affiliates.
 * All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 as published
 * by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 */

#include <stdint.h>
#include <ja310.h>
#include <jlq_private.h>
#include <debug.h>
#include <regs-i2c.h>
#include <mmio.h>
#include <delay_timer.h>
#include <jlq_i2c.h>

static uint32_t i2c_index = 3;

static void delay_us(uint32_t count)
{
	udelay(count);
}

uint32_t i2c_reg_read(uint32_t reg)
{
	uint32_t base = I2C3_BASE;

	switch (i2c_index) {
	case 0:
		base = I2C0_BASE;
		break;
	case 1:
		base = I2C1_BASE;
		break;
	case 2:
		base = I2C2_BASE;
		break;
	case 3:
		base = I2C3_BASE;
		break;
	default:
		ERROR("%s: i2c index (%d) is error\n", __func__, i2c_index);
		break;
	}

	return mmio_read_32(base + reg);
}

void i2c_reg_write(uint32_t reg, uint32_t value)
{
	uint32_t base = I2C3_BASE;

	switch (i2c_index) {
	case 0:
		base = I2C0_BASE;
		break;
	case 1:
		base = I2C1_BASE;
		break;
	case 2:
		base = I2C2_BASE;
		break;
	case 3:
		base = I2C3_BASE;
		break;
	default:
		ERROR("%s: i2c index (%d) is error\n", __func__, i2c_index);
		break;
	}

	mmio_write_32(base + reg, value);
}

void i2cx_wait_for_bb(uint32_t i2cx)
{
	uint32_t reg;
	int32_t timeout = I2C_WAIT_TIMEOUT;

	do {
		reg = i2c_reg_read(I2C_STATUS);
		if (timeout-- < 0) {
			ERROR("%s: (%03d) timeout!!\n", __func__, __LINE__);
			break;
		}
		udelay(1);
	} while (reg & (I2C_STATUS_ACTIVITY));
}

void i2cx_stop(uint32_t i2cx)
{
	i2c_reg_write(I2C_ENABLE, 0);
}

void i2cx_set_dev_addr(uint32_t i2cx, uint16_t addr)
{
	uint32_t val;

	i2c_reg_write(I2C_ENABLE, 0);
	delay_us(2);

	val = i2c_reg_read(I2C_TAR);
	val = (val & (~I2C_TAR_TAR)) | (addr & I2C_TAR_TAR);
	i2c_reg_write(I2C_TAR, val);

	i2c_reg_write(I2C_ENABLE, 1);

	delay_us(2);
}

void i2cx_write_reg(uint32_t i2cx, uint8_t reg, uint8_t data)
{
	uint32_t val;
	int32_t timeout;

	timeout = I2C_WAIT_TIMEOUT;
	do {
		val = i2c_reg_read(I2C_STATUS);
		if (timeout-- < 0) {
			ERROR("%s: (%03d), reg=0x%02X, data=%02X timeout!!\n",
			     __func__, __LINE__, reg, data);
			break;
		}
		udelay(10);
	} while (!(val & I2C_STATUS_TX_FIFO_EMPTY));

	i2c_reg_write(I2C_DATA_CMD, reg);
	i2c_reg_write(I2C_DATA_CMD, (data | (1 << 9)));

	timeout = I2C_WAIT_TIMEOUT;
	do {
		val = i2c_reg_read(I2C_STATUS);
		if (timeout-- < 0) {
			ERROR("%s: (%03d), reg=0x%02X, data=%02X timeout!!\n",
			     __func__, __LINE__, reg, data);
			break;
		}
		udelay(10);
	} while (!(val & I2C_STATUS_TX_FIFO_EMPTY));

	delay_us(1);
}

uint8_t i2cx_read_reg(uint32_t i2cx, uint8_t reg)
{
	uint32_t val;
	int32_t timeout;

	timeout = I2C_WAIT_TIMEOUT;
	do {
		val = i2c_reg_read(I2C_STATUS);
		if (timeout-- < 0) {
			ERROR("%s: (%03d), reg=0x%02X, timeout!!\n",
			     __func__, __LINE__, reg);
			break;
		}
		udelay(10);
	} while (!(val & I2C_STATUS_TX_FIFO_EMPTY));

	i2c_reg_write(I2C_DATA_CMD, reg);
	i2c_reg_write(I2C_DATA_CMD, I2C_DATA_CMD_READ | I2C_DATA_CMD_STOP | I2C_DATA_CMD_RESTART);

	timeout = I2C_WAIT_TIMEOUT;
	do {
		val = i2c_reg_read(I2C_STATUS);
		if (timeout-- < 0) {
			ERROR("%s: (%03d), reg=0x%02X, timeout!!\n",
			     __func__, __LINE__, reg);
			break;
		}
		udelay(10);
	} while (!(val & I2C_STATUS_RX_FIFO_NOT_EMPTY));

	delay_us(2);
	return i2c_reg_read(I2C_DATA_CMD);
}

uint32_t i2cx_init(uint32_t i2cx, uint32_t speed)
{

	if (i2cx > 4) {
		ERROR("%s: i2c index (%d) is error\n", __func__, i2cx);
		return 0;
	} else {
		i2c_index = i2cx;
	}

	i2c_reg_write(I2C_ENABLE, 0);

	delay_us(1);

	/* set as fast mode, master mode , restart enable,10bit address mode */
	if (0 == speed) { /* 100k */
		i2c_reg_write(I2C_CON, (I2C_CON_NOMEANING |
		                        I2C_CON_RESTART_EN |
		                        I2C_CON_7BIT_ADDR |
		                        I2C_CON_STANDARD_MODE |
		                        I2C_CON_MASTER_MODE));

		/*************intial I2C Pulse width *****************/
		i2c_reg_write(I2C_SS_SCL_HCNT, I2C_SS_SCL_HCNT_PARAMS);
		i2c_reg_write(I2C_SS_SCL_LCNT, I2C_SS_SCL_LCNT_PARAMS);
	} else if (1 == speed) {
		i2c_reg_write(I2C_CON, (I2C_CON_NOMEANING |
		                        I2C_CON_RESTART_EN |
		                        I2C_CON_7BIT_ADDR |
		                        I2C_CON_FAST_MODE |
		                        I2C_CON_MASTER_MODE));

		i2c_reg_write(I2C_FS_SCL_HCNT, I2C_FS_SCL_HCNT_PARAMS);
		i2c_reg_write(I2C_FS_SCL_LCNT, I2C_FS_SCL_LCNT_PARAMS);
	} else {
		return 0;
	};

	i2c_reg_write(I2C_TAR, (I2C_TAR_7BITADDR |
	                        I2C_TAR_SPECIAL |
	                        I2C_TAR_GCORSTART));
	i2c_reg_write(I2C_INTR_EN, 0);

	i2c_reg_write(I2C_SDA_HOLD, I2C_SDA_HOLD_PARAMS);
	i2c_reg_write(I2C_RX_TL, 0);
	i2c_reg_write(I2C_TX_TL, 0);

	i2c_reg_write(I2C_ENABLE, 1);

	delay_us(1);
	return 1;
}
